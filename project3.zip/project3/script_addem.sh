Invalid input - 2 arguments must be given
[ajlap@ccc-app-p-u13 project3]$ ./addem 10 100
The total for 1 to 100 using 10 threads is 5050.
[ajlap@ccc-app-p-u13 project3]$ ./addem 5 50
The total for 1 to 50 using 5 threads is 1275.
[ajlap@ccc-app-p-u13 project3]$ ./addem -2 4
You need to specify 1 or more threads
[ajlap@ccc-app-p-u13 project3]$ ./addem 20 50
Too many threads. The maximum is 10
