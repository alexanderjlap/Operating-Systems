Invalid input - 3, 4, or 5 arguments must be given
Format: ./life threads filename generations print input
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0.in 120 n n > answer_bigger_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0-small1.in 40 y n > smaller_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 8 gen0-small6.in 120 n n > small6_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0-small7.in 120 n n > small7_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0-max_number_lines.in 19 y > max_lines_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0-max_number_columns.in 43 y > max_columns_matrix.txt
[ajlap@ccc-app-p-u13 project3]$ ./life 6 gen0-alldie.in 43 y > alldie.txt


